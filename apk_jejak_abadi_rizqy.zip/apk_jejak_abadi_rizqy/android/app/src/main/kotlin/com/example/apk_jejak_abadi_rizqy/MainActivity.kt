package com.example.apk_jejak_abadi_rizqy

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
