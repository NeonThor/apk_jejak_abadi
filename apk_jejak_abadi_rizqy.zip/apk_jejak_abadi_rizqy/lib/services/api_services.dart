import 'dart:convert';
import 'package:http/http.dart' as http;

class ApiService {
  static const String baseUrl = 'https://api.jejakabadi.com';

  static Future<void> submitDonasi(int amount, String userId) async {
    final url = Uri.parse('$baseUrl/donasi');

    final payload = {
      "user_id": userId, // ubah ini jika backend pakai nama lain
      "amount": amount
    };

    print("DEBUG - Sending payload: ${jsonEncode(payload)}");

    final response = await http.post(
      url,
      headers: {
        'Content-Type': 'application/json',
      },
      body: jsonEncode(payload),
    );

    print('DEBUG - Status Code: ${response.statusCode}');
    print('DEBUG - Response Body: ${response.body}');

    if (response.statusCode == 200) {
      print("DEBUG - Donasi berhasil");
    } else {
      throw Exception('Gagal mengirim donasi - ${response.statusCode}');
    }
  }
}
