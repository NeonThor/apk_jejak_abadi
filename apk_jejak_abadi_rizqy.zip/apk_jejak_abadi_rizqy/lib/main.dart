import 'package:flutter/material.dart';
import '/screens/home_screens.dart';

void main() {
  runApp(const JejakAbadiApp());
}

class JejakAbadiApp extends StatelessWidget {
  const JejakAbadiApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Jejak Abadi',
      theme: ThemeData(
        primarySwatch: Colors.green,
        useMaterial3: true,
      ),
      home: const HomeScreen(),
    );
  }
}