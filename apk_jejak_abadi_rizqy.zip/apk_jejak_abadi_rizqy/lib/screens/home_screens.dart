import 'package:flutter/material.dart';
import '/widgets/app_drawer.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final List<String> imagePaths = [
      'lib/images/keuangan.png',
      'lib/images/tabungan.png',
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text('Jejak Abadi'),
      ),
      drawer: const AppDrawer(),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Center(
                child: Text(
                  'Selamat datang di Jejak Abadi',
                  style: TextStyle(fontSize: 18),
                ),
              ),
              const SizedBox(height: 20),
              
              // Gambar horizontal scroll
              SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                  children: imagePaths.map((path) {
                    return Padding(
                      padding: const EdgeInsets.only(right: 12.0),
                      child: GestureDetector(
                        onTap: () {
                          // Tambahkan navigasi atau aksi lain di sini jika perlu
                        },
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(12),
                          child: Image.asset(
                            path,
                            width: 300,
                            height: 200,
                            fit: BoxFit.cover,
                          ),
                        ),
                      ),
                    );
                  }).toList(),
                ),
              ),

              const SizedBox(height: 24),
              const Text(
                'Tentang Aplikasi',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 8),
              const Text(
                'Jejak Abadi adalah aplikasi mobile untuk pengelolaan dana abadi dan manajemen keuangan berkelanjutan. Aplikasi ini bertujuan untuk membantu institusi dan individu dalam merencanakan, mengelola, dan melaporkan penggunaan dana jangka panjang secara transparan dan efisien.',
              ),
              const SizedBox(height: 20),
              const Text(
                'Manfaat:',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              const Text('- Monitoring dana secara real-time'),
              const Text('- Laporan keuangan otomatis dan akurat'),
              const Text('- Meningkatkan transparansi dan akuntabilitas'),
              const SizedBox(height: 16),
              const Text(
                'Tujuan:',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              const Text('- Menyediakan platform digital terpercaya untuk pengelolaan dana abadi'),
              const Text('- Mempermudah pengawasan dan pelaporan penggunaan dana'),
              const SizedBox(height: 16),
              const Text(
                'Pengguna Aplikasi:',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              const Text('- Institusi Pendidikan'),
              const Text('- Yayasan Sosial'),
              const Text('- Pemerintah Daerah'),
              const Text('- Masyarakat Umum yang ingin mengelola dana jangka panjang'),
              const SizedBox(height: 40),
              
            ],
          ),
        ),
      ),
    );
  }
}
