import 'package:flutter/material.dart';

class LaporanDistribusiScreen extends StatelessWidget {
  const LaporanDistribusiScreen({Key? key}) : super(key: key);

  void _navigateToDetail(BuildContext context, String title) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => DetailDistribusiScreen(title: title),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: const Text('Laporan Distribusi'),
        backgroundColor: Colors.deepPurple,
        leading: const BackButton(),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _buildDistribusiCard(
            context,
            title: 'Beasiswa Mahasiswa',
            tanggal: '2025-04-05',
            jumlah: 'Rp 10.000.000',
            imagePath: 'lib/images/beasiswa.png',
          ),
          const SizedBox(height: 16),
          _buildDistribusiCard(
            context,
            title: 'Program Literasi',
            tanggal: '2025-04-12',
            jumlah: 'Rp 5.000.000',
            imagePath: 'lib/images/literasi sekolah.png',
          ),
        ],
      ),
    );
  }

  Widget _buildDistribusiCard(
    BuildContext context, {
    required String title,
    required String tanggal,
    required String jumlah,
    required String imagePath,
  }) {
    return InkWell(
      onTap: () => _navigateToDetail(context, title),
      child: Card(
        elevation: 6,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ClipRRect(
              borderRadius:
                  const BorderRadius.vertical(top: Radius.circular(16)),
              child: Image.asset(imagePath, fit: BoxFit.cover, height: 150, width: double.infinity),
            ),
            Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title,
                      style: const TextStyle(
                          fontSize: 18, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  Text('Tanggal: $tanggal'),
                  Text('Total Distribusi: $jumlah',
                      style: const TextStyle(
                          fontWeight: FontWeight.bold, color: Colors.deepPurple)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class DetailDistribusiScreen extends StatelessWidget {
  final String title;

  const DetailDistribusiScreen({super.key, required this.title});

  @override
  Widget build(BuildContext context) {
    final isBeasiswa = title.contains('Beasiswa');
    return Scaffold(
      appBar: AppBar(
        title: Text(title),
        backgroundColor: Colors.deepPurple,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: ListView(
          children: [
            Text('📊 Statistik Program',
                style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 16),
            _buildInfoTile('Skor Favorit', isBeasiswa ? '4.8 / 5' : '4.2 / 5'),
            _buildInfoTile('Jumlah Sisa Dana',
                isBeasiswa ? 'Rp 2.000.000' : 'Rp 1.000.000'),
            _buildInfoTile('Jumlah Lulus', isBeasiswa ? '120 orang' : '90 siswa'),
            _buildInfoTile('Persentase Keterima',
                isBeasiswa ? '85%' : '70%'),
            _buildInfoTile('Persentase Ditolak', isBeasiswa ? '15%' : '30%'),
            _buildInfoTile('Kerugian (Loss)',
                isBeasiswa ? 'Rp 500.000' : 'Rp 200.000'),
            _buildInfoTile('Tanggal Diterima',
                isBeasiswa ? '2025-04-05' : '2025-04-12'),
            _buildInfoTile('Batas Waktu',
                isBeasiswa ? '2025-06-30' : '2025-07-15'),
            const SizedBox(height: 30),
            const Text(
              '💡 Catatan:',
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
            Text(isBeasiswa
                ? 'Beasiswa ini termasuk dalam program nasional Indonesia seperti LPDP atau Beasiswa Kemendikbud.'
                : 'Program Literasi ini dijalankan di sekolah-sekolah di Pulau Jawa dalam rangka Gerakan Literasi Sekolah.'),
          ],
        ),
      ),
    );
  }

  Widget _buildInfoTile(String label, String value) {
    return ListTile(
      title: Text(label),
      trailing: Text(value,
          style: const TextStyle(fontWeight: FontWeight.bold)),
    );
  }
}
