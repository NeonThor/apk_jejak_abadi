import 'package:flutter/material.dart';

class InvestmentItem {
  final String type;
  final String name;
  final String imagePath;
  final DateTime buyDate;
  final DateTime sellDate;
  final int totalBuy;
  final int remaining;
  final int profit;
  final int loss;
  final double profitPercentage;

  InvestmentItem({
    required this.type,
    required this.name,
    required this.imagePath,
    required this.buyDate,
    required this.sellDate,
    required this.totalBuy,
    required this.remaining,
    required this.profit,
    required this.loss,
    required this.profitPercentage,
  });
}

class TrackingInvestasiScreen extends StatelessWidget {
  const TrackingInvestasiScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final List<InvestmentItem> investments = [
      InvestmentItem(
        type: 'Saham',
        name: 'Saham ESG',
        imagePath: 'lib/images/saham_graph.png', // Gambar grafik saham
        buyDate: DateTime(2025, 4, 10),
        sellDate: DateTime(2025, 5, 10),
        totalBuy: 100000000,
        remaining: 30000000,
        profit: 20000000,
        loss: 0,
        profitPercentage: 25.0,
      ),
      InvestmentItem(
        type: 'Reksa Dana',
        name: 'Reksa Dana Syariah',
        imagePath: 'lib/images/reksadana_wallet.png', // Gambar dompet & koin
        buyDate: DateTime(2025, 4, 1),
        sellDate: DateTime(2025, 5, 1),
        totalBuy: 80000000,
        remaining: 50000000,
        profit: 10000000,
        loss: 0,
        profitPercentage: 12.5,
      ),
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text('Tracking Investasi'),
        leading: BackButton(),
      ),
      body: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: investments.length,
        itemBuilder: (context, index) {
          final item = investments[index];
          return GestureDetector(
            onTap: () {
              showModalBottomSheet(
                context: context,
                backgroundColor: Colors.white,
                shape: const RoundedRectangleBorder(
                  borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
                ),
                builder: (context) => InvestmentDetail(item: item),
              );
            },
            child: Card(
              elevation: 6,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
              margin: const EdgeInsets.only(bottom: 20),
              child: Column(
                children: [
                  ClipRRect(
                    borderRadius: const BorderRadius.vertical(top: Radius.circular(16)),
                    child: Image.asset(item.imagePath, height: 150, width: double.infinity, fit: BoxFit.cover),
                  ),
                  ListTile(
                    title: Text(item.name, style: const TextStyle(fontWeight: FontWeight.bold)),
                    subtitle: Text('Tanggal Beli: ${item.buyDate.toLocal().toString().split(' ')[0]}'),
                    trailing: Text('Rp ${item.remaining}', style: const TextStyle(fontWeight: FontWeight.bold)),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}

class InvestmentDetail extends StatelessWidget {
  final InvestmentItem item;

  const InvestmentDetail({super.key, required this.item});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(24.0),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text('${item.name} (${item.type})', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          detailRow('Jumlah Beli:', 'Rp ${item.totalBuy}'),
          detailRow('Jumlah Tersisa:', 'Rp ${item.remaining}'),
          detailRow('Keuntungan:', 'Rp ${item.profit}'),
          detailRow('Kerugian:', 'Rp ${item.loss}'),
          detailRow('Profit Persen:', '${item.profitPercentage.toStringAsFixed(2)} %'),
          detailRow('Tanggal Beli:', '${item.buyDate.toLocal().toString().split(' ')[0]}'),
          detailRow('Tanggal Jual:', '${item.sellDate.toLocal().toString().split(' ')[0]}'),
          const SizedBox(height: 20),
        ],
      ),
    );
  }

  Widget detailRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: const TextStyle(fontWeight: FontWeight.w500)),
          Text(value),
        ],
      ),
    );
  }
}
