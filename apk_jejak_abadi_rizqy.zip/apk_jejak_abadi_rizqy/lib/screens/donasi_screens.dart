import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '/services/api_services.dart';
import 'donasi_success_screen.dart';

class DonasiScreen extends StatefulWidget {
  const DonasiScreen({super.key});

  @override
  State<DonasiScreen> createState() => _DonasiScreenState();
}

class _DonasiScreenState extends State<DonasiScreen> {
  final TextEditingController _nominalController = TextEditingController();
  final List<int> presetAmounts = [
    1000, 10000, 20000, 50000, 100000, 150000, 200000, 250000, 300000, 1000000
  ];
  int? selectedAmount;
  bool _loading = false;

  String _formatCurrency(int value) {
    final formatCurrency = NumberFormat.currency(locale: 'id', symbol: '', decimalDigits: 0);
    return formatCurrency.format(value);
  }

  Future<void> _kirimDonasi() async {
    final cleanText = _nominalController.text.replaceAll('.', '');
    final amount = int.tryParse(cleanText);
    if (amount == null || amount <= 0) return;

    setState(() => _loading = true);
    try {
      await ApiService.submitDonasi(amount, "user123");
      if (!mounted) return;
      Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => const DonasiSuccessScreen()),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Gagal mengirim donasi. Silakan coba lagi.")),
      );
    } finally {
      setState(() => _loading = false);
    }
  }

  void _updateTextFieldFromDropdown(int? value) {
    if (value != null) {
      _nominalController.text = _formatCurrency(value);
      setState(() => selectedAmount = value);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Donasi Dana Abadi')),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Image.asset('assets/images/donasi.png', height: 180),
              const SizedBox(height: 20),
              const Text(
                'Bantu Wujudkan Masa Depan yang Lebih Baik',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 12),
              const Text(
                'Donasi Anda akan digunakan untuk mendukung program pendidikan, '
                'pemberdayaan ekonomi, dan bantuan darurat bagi masyarakat yang membutuhkan.',
                style: TextStyle(fontSize: 16, color: Colors.black87),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 30),
              DropdownButtonFormField<int>(
                decoration: const InputDecoration(
                  labelText: "Pilih Nominal Donasi",
                  border: OutlineInputBorder(),
                ),
                value: selectedAmount,
                items: presetAmounts.map((amount) {
                  return DropdownMenuItem<int>(
                    value: amount,
                    child: Text("Rp ${_formatCurrency(amount)}"),
                  );
                }).toList(),
                onChanged: _updateTextFieldFromDropdown,
              ),
              const SizedBox(height: 16),
              TextField(
                controller: _nominalController,
                decoration: const InputDecoration(
                  labelText: 'Atau Masukkan Nominal Manual (Rp)',
                  border: OutlineInputBorder(),
                ),
                keyboardType: TextInputType.number,
                onChanged: (value) {
                  // Otomatis hilangkan titik saat pengguna mengetik
                  final digitsOnly = value.replaceAll(RegExp(r'\D'), '');
                  if (digitsOnly.isNotEmpty) {
                    final formatted = _formatCurrency(int.parse(digitsOnly));
                    _nominalController.value = TextEditingValue(
                      text: formatted,
                      selection: TextSelection.collapsed(offset: formatted.length),
                    );
                  }
                },
              ),
              const SizedBox(height: 20),
              _loading
                  ? const CircularProgressIndicator()
                  : ElevatedButton(
                      onPressed: _kirimDonasi,
                      style: ElevatedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 12),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
                        backgroundColor: Colors.purple,
                      ),
                      child: const Text(
                        'Donasi Sekarang',
                        style: TextStyle(fontSize: 16, color: Colors.white),
                      ),
                    ),
            ],
          ),
        ),
      ),
    );
  }
}
